from django.apps import AppConfig


class MigUserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mig_user'
